from django.http import HttpResponse
from django.shortcuts import redirect



# def mopd_user_requierd():
    